#pragma

#ifndef hGlobal
#define hGlobal

#define PLUGIN_NAME		"MinimalMinimap"
#define PLUGIN_VERSION	((0x1000000ul * 1ul) + (0x10000ul * 11ul) + (0x100ul * 0ul) + (0x1ul * 0ul))

#endif