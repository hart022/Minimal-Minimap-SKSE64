#include <ShlObj.h>

#include <f4se/PluginManager.h>
#include <f4se/GameMenus.h>

#include <f4se_common/f4se_version.h>

#include "Global.h"
#include "Trampoline.h"
#include "Papyrus.h"
#include "InterfaceManager.h"
#include "Utility.h"
#include "Message.h"
#include "Serialize.h"

/* Plugin Query */
extern "C" {

	bool F4SEPlugin_Query(const F4SEInterface* f4se, PluginInfo* info) {
		std::string gLogPath{ "\\My Games\\Fallout4\\F4SE\\" PLUGIN_NAME ".log" };
		gLog.OpenRelative(CSIDL_MYDOCUMENTS, gLogPath.c_str());
		gLog.SetPrintLevel(IDebugLog::kLevel_Error);
		gLog.SetLogLevel(IDebugLog::kLevel_DebugMessage);

		// populate info structure
		info->infoVersion = PluginInfo::kInfoVersion;
		info->name = PLUGIN_NAME;
		info->version = PLUGIN_VERSION;


		if (f4se->runtimeVersion != RUNTIME_VERSION_1_10_163) {
			_MESSAGE("unsupported runtime version %d", f4se->runtimeVersion);
			return false;
		}

		return true;
	}

	bool F4SEPlugin_Load(const F4SEInterface* f4se) {
		_DMESSAGE("%s Loaded", PLUGIN_NAME);
		_DMESSAGE("ANSI(windows-1252) encoded");

		((F4SEMessagingInterface*)f4se->QueryInterface(kInterface_Messaging))->RegisterListener(f4se->GetPluginHandle(), "F4SE", Message::F4SEMessageHandler);
		((F4SEPapyrusInterface*)f4se->QueryInterface(kInterface_Papyrus))->Register(Papyrus::RegisterFuncs);
		((F4SEScaleformInterface*)f4se->QueryInterface(kInterface_Scaleform))->Register(PLUGIN_NAME, InterfaceManager::RegisterScaleform);
		Utility::g_task = (F4SETaskInterface*)f4se->QueryInterface(kInterface_Task);

		if (!Trampoline::DoAlloc())
		{
			return false;
		}

		if (!Serialize::RegisterSerialize((F4SESerializationInterface*)f4se->QueryInterface(kInterface_Serialization), f4se->GetPluginHandle()))
		{
			return false;
		}

		return true;
	}
};