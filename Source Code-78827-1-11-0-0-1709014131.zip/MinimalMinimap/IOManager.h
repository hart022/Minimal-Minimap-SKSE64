#pragma once

#ifndef hIOManager
#define hIOManager

namespace IOManager
{
	void SetStatic();
}

#endif

