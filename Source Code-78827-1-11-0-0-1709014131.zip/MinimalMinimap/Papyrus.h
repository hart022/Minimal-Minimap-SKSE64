#pragma once

#ifndef hPapyrus
#define hPapyrus

#include <f4se/PapyrusNativeFunctions.h>

namespace Papyrus
{
	bool RegisterFuncs(VirtualMachine* vm);
};

#endif

