#pragma once

#ifndef hSerialize
#define hSerialize

#include <f4se/PluginAPI.h>

namespace Serialize
{
	extern UInt32 RecordSignature;
	extern UInt32 DataSignature;

	void OnSaveGame(const F4SESerializationInterface*);
	void OnLoadGame(const F4SESerializationInterface*);

	bool RegisterSerialize(F4SESerializationInterface*, PluginHandle);
};

#endif // !hSerialize

