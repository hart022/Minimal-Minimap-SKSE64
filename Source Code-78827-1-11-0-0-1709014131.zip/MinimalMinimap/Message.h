#pragma once

#ifndef hMessage
#define hMessage

#include <f4se/PluginAPI.h>

namespace Message
{
	void F4SEMessageHandler(F4SEMessagingInterface::Message*);
};

#endif // !hMessage

