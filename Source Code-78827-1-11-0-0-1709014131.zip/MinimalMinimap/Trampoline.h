#pragma once

#ifndef hTrampoline
#define hTrampoline

namespace Trampoline
{
	bool DoAlloc();
};

#endif

